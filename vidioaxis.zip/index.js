const cheerio = require('cheerio');
const fs = require('fs')
const figlet = require('figlet');
const colors = require('@colors/colors');
const readlinesync = require('readline-sync')
var {
    HttpsProxyAgent
} = require('https-proxy-agent')
var random_name = require('node-random-name')

const randstr = length => {
    var text = "";
    var possible =
        "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
};
const randnmr = length => {
    var text = "";
    var possible =
        "0123456789109876543210";
    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
};


const getAccount = (email, password) => new Promise((resolve, reject) => {
    const index = fetch('https://www.vidio.com/api/register', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'email=' + email + '&password=' + password,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const getAccount2 = () => new Promise((resolve, reject) => {
	    const getconfig = fs.readFileSync('config.json', 'utf-8')
    const config = JSON.parse(getconfig)
    const domain = config.domain
    const password = config.password
        var first = random_name({
            first: true,
            gender: 'male',
        }),
        last = random_name({
            last: true
        })
    const email = `${first}${last}${randnmr(5)}@${domain}`
    const index = fetch('https://www.vidio.com/api/register', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'email=' + email + '&password=' + password,

        })
        .then(async (res) => {
            const data = await res.json()
            const authtoken = data.auth.authentication_token
            const accesstoken = data.auth_tokens.access_token
            const active = true
            resolve({
            	active,
                authtoken,
                accesstoken,
                email,
                password
            })
        });
    return index
});

const loginAccount = (email, password) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/api/login', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'login=' + email + '&password=' + password,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const submitOTP = (phone, xtoken, accessToken, email) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/api/profile/phone/send_verification_code', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'X-User-Email': email,
                'X-User-Token': xtoken,
                'X-Authorization': accessToken,
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'phone=' + phone,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const submitOTP2 = (phone2, xtoken, accessToken, email) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/api/profile/phone/send_verification_code', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'X-User-Email': email,
                'X-User-Token': xtoken,
                'X-Authorization': accessToken,
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'phone=' + phone2,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});
const verifOTP = (xtoken, accessToken, email, otpnya) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/api/profile/phone/verify', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'X-User-Email': email,
                'X-User-Token': xtoken,
                'X-Authorization': accessToken,
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'verification_code=' + otpnya,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const verifOTP2 = (xtoken, accessToken, email, otpnya2) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/api/profile/phone/verify', {
            method: 'POST',
            headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'X-User-Email': email,
                'X-User-Token': xtoken,
                'X-Authorization': accessToken,
                'content-type': 'application/x-www-form-urlencoded',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
            body: 'verification_code=' + otpnya2,

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const claimPaket = (phone, email, xtoken, accessToken) => new Promise((resolve, reject) => {
    const index = fetch('https://api.vidio.com/telco/claim', {
  method: 'POST',
 headers: {
                Host: 'api.vidio.com',
                referer: 'android-app://com.vidio.android',
                'x-api-platform': 'app-android',
                'x-api-auth': 'laZOmogezono5ogekaso5oz4Mezimew1',
                'user-agent': 'tv-android/1.92.1 (437)',
                'x-api-app-info': 'tv-android/13/1.92.1-437',
                'accept-language': 'id',
                'X-User-Email': email,
                'X-User-Token': xtoken,
                'X-Authorization': accessToken,
                'content-type': 'application/vnd.api+json',
                // 'content-length': '53',
                'accept-encoding': 'gzip',
                'x-visitor-id': '' + randstr(16),
            },
  body: `{"data":{"type":"telco_claim_otp_request","attributes":{"msisdn":"${phone}"}}}`

        })
        .then(async (res) => {
            const data = await res.json()
            resolve({
                data,
            })
        });
    return index
});

const loginWeb = (email, password, token) => new Promise((resolve, reject) => {
    const index = fetch('https://m.vidio.com/users/login', {
  method: 'POST',
  headers: {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'cookie': 'ahoy_visitor=615aa3ca-deaf-4094-aa3e-04a8a74f75d4; ahoy_visit=f11d29c7-ad0a-40d7-b2eb-c14270300a5d; _gcl_au=1.1.1363368754.1737298831; _ga=GA1.3.2043218518.1737298834; _gid=GA1.3.261303921.1737298834; _fbp=fb.1.1737298834513.401849239910931382; _tt_enable_cookie=1; _ttp=3mhvki6D4cDvM8HUDKhngAXUhCB.tt.1; cebs=1; afUserId=09fc8959-e0ef-4032-8f5a-f11c51f99c75-p; _ce.clock_data=304%2C182.3.51.171%2C1%2Cf51bb482c660d0eeadd1f058058a2b35%2CChrome%2CID; AF_SYNC=1737298841108; USER_DATA=%7B%22attributes%22%3A%5B%5D%2C%22subscribedToOldSdk%22%3Afalse%2C%22deviceUuid%22%3A%221bd549e9-2be4-4ce5-ad9d-8b6d7b652c09%22%2C%22deviceAdded%22%3Afalse%7D; moe_uuid=1bd549e9-2be4-4ce5-ad9d-8b6d7b652c09; _gid=GA1.2.261303921.1737298834; country_id=ID; _ga_JBTBSESXVN=GS1.1.1737298847.1.1.1737299080.60.0.0; _ga=GA1.1.2043218518.1737298834; cebsp_=7; SESSION=%7B%22sessionKey%22%3A%226c19da2a-5ab1-4185-b0dc-bbc4377b1ca2%22%2C%22sessionStartTime%22%3A%222025-01-19T15%3A00%3A41.945Z%22%2C%22sessionMaxTime%22%3A1800%2C%22customIdentifiersToTrack%22%3A%5B%5D%2C%22sessionExpiryTime%22%3A1737300891201%2C%22numberOfSessions%22%3A1%7D; _vidio_session=HSksYU4aRS%2FDqp6r%2FA4qiz2nZjBerpxT8W92Z0IBztj2ChbavOWQuXl47gsKfY0qjt80mYBlBgwc53jrqBCB02sRxCyblrMWtjb3FImKiDzizjw7%2FmOxXZHwZMQ8SasDQRu7%2Bybn8jR7DsWGmVnKcwWi4xUBKPKiJvtxs5mOel%2FbZHVT93BTeWK%2BghDhwnsFmVMWeb72uOmO480kvyMaDfY%2FWw%2Fj2UuI0tHsOnIK23rSUHXlv0Mu8I4DCWDk3RXpcaCcFAaQW10cpjX17Rakbf09FCfp%2Fp48fAiLJW%2FrcuL0palH19Dk7gNMAOKiNp0iz%2FIhMKD3mOs57H2TF3Ha2kmCYRctLJJFLTWbk9TmByuibbWIz9Nt%2FiKxBzWZ9r7A4NTjAm1IFD%2FTp%2BS%2BuxA36UAHO1GjKnYO5EU%3D--h%2BBTXr12taJs6Icl--hTELZZEm0CG2iJNUoV62RQ%3D%3D; _ce.s=v~a66309bf9b94f20314a7ed657532721e41feca3e~lcw~1737299443865~vir~new~lva~1737298835649~vpv~0~v11.fhb~1737298836427~v11.lhb~1737298848853~v11.cs~265059~v11.s~23a69760-d676-11ef-b896-47bfbfa94fc4~v11.sla~1737299443868~gtrk.ngv~%7B%7D~gtrk.cnv~7cd~gtrk.la~m63r8e0w~v11slnt~1737298881891~v11.send~1737299443827~lcw~1737299443869',
    'origin': 'https://m.vidio.com',
    'pragma': 'no-cache',
    'priority': 'u=0, i',
    'referer': 'https://m.vidio.com/users/login',
    'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
  },
  body: new URLSearchParams({
    'authenticity_token': token,
    'user[login]': email,
    'user[password]': password,
    'user[remember_me]': '1'
  })

        })
        .then(async (res) => {
            const data = await res.text()
            resolve({
                data,
            })
        });
    return index
});


(async () => {
    console.log(
        colors.white(
            figlet.textSync('VIDIO X AXIS', {
                horizontalLayout: 'fitted'
            })
        )
    );
    console.log('       By AMFCODE');

    const getconfig = fs.readFileSync('config.json', 'utf-8')
    const config = JSON.parse(getconfig)
    const domain = config.domain
    const password = config.password
    const proxy = config.proxy
    var first = random_name({
            first: true,
            gender: 'male',
        }),
        last = random_name({
            last: true
        })
    const email = `${first}${last}${randnmr(5)}@${domain}`
    const register = await getAccount(email, password)
    if (register.data.auth.active == true) {
        console.log(colors.green(`[~] ${email} | ${password} | Successfully Register!`))
        const getToken = await loginAccount(email, password)
        const xtoken = getToken.data.auth.authentication_token
        const accessToken = getToken.data.auth_tokens.access_token
        const phone = readlinesync.question('    Phone Axis : ')
        const sendOTP = await submitOTP(phone, xtoken, accessToken, email)
        if (sendOTP.data.status == "pending") {
            console.log(colors.green(`    ${sendOTP.data.message}`))
            const otpnya = readlinesync.question('    OTP Axis : ')
            const otpVerif = await verifOTP(xtoken, accessToken, email, otpnya)
            if (otpVerif.data.status == 'verified') {
                console.log(colors.green(`    ${otpVerif.data.message}`))
                console.log(colors.blue('[+] Silahkan Membeli Paket Vidio Di AxisNet\n    Jika Sudah Silahkan Tekan Enter!'))
                const phone2 = readlinesync.question('    Phone New : ')
                const sendOTP2 = submitOTP2(phone2, xtoken, accessToken, email)
                if (sendOTP2.data.status == "pending") {
                    console.log(colors.green(`    ${sendOTP2.data.message}`))
                    const otpnya2 = readlinesync.question('    OTP New : ')
                    const otpVerif2 = await verifOTP2(xtoken, accessToken, email, otpnya2)
                    if (otpVerif2.data.status == 'verified') {
                        console.log(colors.green(`    ${otpVerif2.data.message}`))
                        const newAccount = await getAccount2()
                        if (newAccount.active == true) {
                        	console.log(colors.green(`[~] ${newAccount.email} | ${newAccount.password} | Successfully Register`))
                        	const xtoken2 = newAccount.authtoken
                        	const accessToken2 = newAccount.accesstoken
                        	const email2 = newAccount.email
                            const claim = await claimPaket(phone, email2, xtoken2, accessToken2)
                            console.log(claim.data)
                        } else {
                        	console.log(colors.red(`[~] ${email} | ${password} | Failed Register!`))
                        }
                    } else {
                        console.log(colors.red('    Yahh, nomer hp baru kamu tidak terverifikasi!'))
                    }
                } else {
                    console.log(colors.red('    Failed Send OTP NEW'))
                }
            } else {
                console.log(colors.red('    Yahh, nomer hp axis kamutidak terverifikasi!'))
            }
        } else {
            console.log(colors.red('    Failed Send OTP Axis'))
        }
    } else {
        console.log(colors.red(`[~] ${email} | ${password} | Failed Register!`))
    }
})();